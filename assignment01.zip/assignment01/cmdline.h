//
// Created by aniru on 1/11/2022.
//

#ifndef MSDSCRIPT_CMDLINE_H
#define MSDSCRIPT_CMDLINE_H

int use_arguments(int argc, char **argv);

#endif //MSDSCRIPT_CMDLINE_H
